﻿
 GOT Wasteland v2.3 instructions
 ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯
 - Put the "antihack" folder and "GoT_Wasteland-config.sqf" into your main ARMA 3 directory (where arma3.exe is located)

 - If there are existing files, overwrite them.

 - The mission file "Sandbox65_GoT_Wasteland_V23.Stratis.pbo" goes into the mpmissions folder

 - To edit the settings open the "GoT_Wasteland-config.sqf" with any text editor.

 Battleye instructions
 ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯

    For BattleEye, please put the .TXT filters from the be-filters folder of this archive in the BattlEye folder of your server, which is located where your .RPT log files are at.

    By default, this folder should be at "%LocalAppData%\Arma 3\BattlEye", or in the folder defined by the "-profiles" options of your arma3server.exe shortcut.

    If you are unsure, simply add "-BEPath=BattlEye" to your arma3server.exe shortcut, and place the .TXT files in the BattlEye folder where arma3server.exe is located.

    It is recommended to only use the filters provided with this mission, as those from other sources may cause false positives.
	
    Fitlers will be added to and/or updated later :)

    keep an eye on our github repo's
	


